from validacao import validar_imei
from registro_log import registro_log_sinc

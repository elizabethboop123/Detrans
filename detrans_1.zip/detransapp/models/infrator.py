from pessoa import Pessoa


class Infrator(Pessoa):
    class Meta:
        app_label = "detransapp"

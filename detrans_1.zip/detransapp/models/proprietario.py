from pessoa import Pessoa


class Proprietario(Pessoa):
    class Meta:
        app_label = "detransapp"

from detrans.settings.vanessa import *
